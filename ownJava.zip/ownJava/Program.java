public class Program {
    public static void main(String[] args) {
        System.out.println("My name is Vincent Guerena");
        System.out.println("I am 28 years old");
        System.out.println("My hometown is Lake Forest, CA");
    }
}